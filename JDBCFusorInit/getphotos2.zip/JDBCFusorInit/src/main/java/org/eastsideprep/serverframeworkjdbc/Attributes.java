/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.eastsideprep.serverframeworkjdbc;

/**
 *
 * @author bray
 */
public class Attributes {
    boolean on; //fusor on or off?
    int vpressure; //vacuum pressure
     
    
    //TODO: figure out how to add the rest of the attributes intto this class
    //Ex: How to we measure "Deuterium" as listed in the status requirements? 
    //What data type is "Deuterium" quantified as?
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.eastsideprep.serverframeworkjdbc;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import static org.eastsideprep.serverframeworkjdbc.ServerFrameworkJDBC.messages;

/**
 *
 * @author gmein
 */
public class Database {

    public static Connection conn;

    Database() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.print("Error creating datbase object: ");
            System.out.println(ex);
        }
    }

    // sets the conn field to a connection with the course_requests database.
    // if connection is unsuccessful, prints the detail message of the
    // exception (a string associated with it on construction), a 5
    // character code associated with the SQL state, and the vendor-specific
    // error code associated with the error.
    public void connect() {
        System.out.println("Attempting to connect...");
        try {
            this.conn = DriverManager.getConnection("jdbc:mysql://localhost/FusorDB", "user", "password"); //if you test this locally change it to your DB info
            System.out.println("Connection successful");
        } catch (SQLException ex) {
            System.out.print("Error connecting to database: ");
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }

    // closes the conn field's connection, prints exception is unsuccessful
    public void disconnect() {

        try {
            this.conn.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // returns the id of the last row inserted into the database
    // if unsuccessful, returns -1
    public int getLastID() {
        try {
            int lastID = 0;
            Statement stmt = conn.createStatement();
            stmt.executeQuery("SELECT LAST_INSERTED_ID() AS id;");
            ResultSet rs;

            rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                lastID = rs.getInt(1);
            }
            return lastID;
        } catch (Exception e) {
            return -1;
        }
    }

    // prints the contents of the table.
    // first prints column names and types, then prints the row id and first
    // two columns of all rows. prints exception if unsuccessful
    public void dumpTable(String tableName) {

        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from " + tableName); // select everything in the table

            System.out.println();
            System.out.println(tableName + ":");

            ResultSetMetaData rsmd = rs.getMetaData();
            int numberOfColumns = rsmd.getColumnCount();
            for (int i = 1; i <= numberOfColumns; i++) {
                System.out.println(rsmd.getColumnName(i) + ",  " + rsmd.getColumnTypeName(i)); // prints column name and type
            }

            System.out.println();
            System.out.println("Rows:");

            while (rs.next()) { // prints the id and first two columns of all rows
                System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
            }

            System.out.println();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // return all tables to user
    String showTables() {
        StringBuilder result = new StringBuilder();
        try {
            String sql = "show tables;";
            PreparedStatement statement = conn.prepareStatement(sql);

            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                result.append(rs.getString("Tables_in_sakila"));
                result.append(" ");
            }

        } catch (Exception e) {
            System.out.println(e);
        }

        return result.toString();
    }

    static Object addImages(spark.Request req, Part file) {

        try {
            long size = file.getSize();
//            byte[] bytes = new byte[(int) size];
//            
//            
//            file.getInputStream().read(bytes, 0, (int) size); //file to byte array
            //System.out.println(message + "---------------------------"); //debugging
            //message = req.queryParams("message").toString();
            // the mysql insert statement
            String query = " insert into pictures (Picture)" //sql query, insert into database
                    + " values (?)";

            // create the mysql insert preparedstatement
            InputStream is = file.getInputStream();
            PreparedStatement preparedStmt = conn.prepareStatement(query);
            preparedStmt.setBinaryStream(1, is);

            //preparedStmt.setString(1, images.toString()); //sets the one parameter
            // execute the preparedstatement
            preparedStmt.execute();

            //conn.close();
            return "temp";
        } catch (Exception e) {
            System.err.println("Got an exception in addMessagesToTable! " + e);

        }
        return "Should not get here";
    }

    
    static ArrayList<byte[]> getImage(spark.Request req, spark.Response res) {
       int k = 0;
       byte[] data = null;
       ArrayList photos = new ArrayList<byte[]>();

        try {

            String query2 = "select Picture from pictures;";
            PreparedStatement ps2 = conn.prepareStatement(query2);
            ResultSet rs2 = ps2.executeQuery();
            while (rs2.next()) {
                k++;
            }
            for (int i = 1; i <= k; i++) {
       
                String query = "select Picture as file from pictures WHERE Picture_id = (?);";

                PreparedStatement preparedStmt = conn.prepareStatement(query);
                preparedStmt.setInt(1, i);
                ResultSet rs = preparedStmt.executeQuery();

                while (rs.next()) {
                    data = rs.getBytes("file");
                }
                photos.add(data);
            }
            

                return photos;

        }catch (Exception e) {
            System.err.println("Got an exception in addMessagesToTable! " + e);
        }
        

        return null;
    }

    // executes a prepared sql statement specified by the sql argument
    // the first parameter of that prepared statement will be the parameter argument
    // prints exception if unsuccessful
    void executePS(String sql, int parameter) {

        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setInt(1, parameter);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
//                System.out.println("Statement executed: " + sql + ", " + parameter + ", rows affected:" + rowsAffected);
            }

        } catch (Exception e) {
            System.out.println(e);
        }

    }

}
